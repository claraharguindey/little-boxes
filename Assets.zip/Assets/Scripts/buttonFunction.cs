using UnityEngine;

public class ImageToggleOnClick : MonoBehaviour
{
    public GameObject imageToToggle; // La imagen que se va a mostrar/ocultar

    void Start()
    {
        // Asegurarse de que la imagen está inicialmente oculta
        if (imageToToggle != null)
        {
            imageToToggle.SetActive(false);
        }
        else
        {
            Debug.LogError("No se ha asignado la imagen a mostrar/ocultar en el inspector.");
        }
    }

    void OnMouseDown()
    {
        if (imageToToggle != null)
        {
            // Alternar la visibilidad de la imagen
            imageToToggle.SetActive(true);
        }
    }
}
