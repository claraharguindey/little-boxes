using UnityEngine;
using System.Collections;

public class ImageSwitcher : MonoBehaviour
{
    public GameObject[] images; // Las 8 imágenes a alternar

    private void Start()
    {
        // Asegurarse de que hay exactamente 8 imágenes
        if (images.Length != 20)
        {
            Debug.LogError("Debe haber exactamente 20 imágenes asignadas.");
            return;
        }

        // Desactivar todas las imágenes al inicio
        foreach (GameObject img in images)
        {
            img.SetActive(false);
        }

        // Iniciar la coroutine para alternar las imágenes con una espera inicial de 30 segundos
        StartCoroutine(SwitchImagesWithInitialDelay());
    }

    private IEnumerator SwitchImagesWithInitialDelay()
    {

        while (true)
        {
            yield return new WaitForSeconds(29f);
            ShowImagesGroup(0, 5);
            yield return new WaitForSeconds(10f);
            HideImagesGroup(0, 5);


            yield return new WaitForSeconds(15.5f);
            ShowImagesGroup(5, 10);
            yield return new WaitForSeconds(10f);
            HideImagesGroup(5, 10);

            yield return new WaitForSeconds(2.5f);
            ShowImagesGroup(10, 15);
            yield return new WaitForSeconds(17f);
            HideImagesGroup(10,15);

            yield return new WaitForSeconds(20f);
            ShowImagesGroup(15, 20);
            yield return new WaitForSeconds(10f);
            HideImagesGroup(15, 20);
        }
    }

    private void ShowImagesGroup(int startIndex, int endIndex)
    {
        // Desactivar todas las imágenes primero
        foreach (GameObject img in images)
        {
            img.SetActive(false);
        }

        // Activar el grupo de imágenes especificado
        for (int i = startIndex; i < endIndex; i++)
        {
            images[i].SetActive(true);
        }
    }

    private void HideImagesGroup(int startIndex, int endIndex)
    {
        // Desactivar todas las imágenes primero
        foreach (GameObject img in images)
        {
            img.SetActive(false);
        }

        // Activar el grupo de imágenes especificado
        for (int i = startIndex; i < endIndex; i++)
        {
            images[i].SetActive(false);
        }
    }
}
