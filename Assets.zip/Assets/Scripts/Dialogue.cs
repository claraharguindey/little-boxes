using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Dialogue : MonoBehaviour
{
    public TextMeshProUGUI textComponent;
    public string[] lines;
    public float textSpeed;

    private int index;

    // Añadir un array de tiempos específicos para cada línea
    private float[] lineTimes = new float[]
    {
        1f,    // Welcome to Little boxes!
        4f,    // An exemplary neighbourhood
        8f,    // Keep it as good as it is!
        12f,    // 3
        13f,    // 2
        14.5f, // 1...
        17f,   // Little boxes on the hillside
        20f, // Little boxes made of ticky-tacky
        23f,   // Little boxes on the hillside
        26f, // Little boxes all the same
        28.5f,   // There's a green one and a pink one
        32f, // And a blue one and a yellow one
        35f,   // And they're all made out of ticky-tacky
        38f, // And they all look just the same ----------
        42.5f,   // And the people in the houses
        45f, // All went to the university
        48f,   // Where they were put in boxes
        51f, // And they came out all the same 
        54f,   // And there's doctors and lawyers
        56.7f,   // And business executives
        60f, // And they're all made out of ticky-tacky
        63f,   // And they all look just the same ----------
        67f,   // And they all play on the golf course
        71f,   // And drink their martinis dry
        73f,   // And they all have pretty children
        76f,   // And the children go to school
        79f,   // And the children go to summer camp
        82f,   // And then to the university
        84.5f,   // Where they are put in boxes
        88f,   // And they come out all the same ------------
        92f,   // And the boys go into business
        94.5f,   // And marry and raise a family
        98.5f,   // In boxes made of ticky-tacky
        101.5f,   // And they all look just the same
        104f,   // There's a pink one and a green one
        107f,   // And a blue one and a yellow one
        109.5f,   // And they're all made out of ticky-tacky
        113f, // And they all look just the same
        115f,  
        116f,  
        117f,  
        118f,  
        119f,  
    };

    void Start()
    {
        textComponent.text = string.Empty;
        StartCoroutine(StartDialogueWithDelay());
    }

    IEnumerator StartDialogueWithDelay()
    {
        yield return new WaitForSeconds(2f); // Espera inicial antes de comenzar el diálogo
        StartDialogue();
        yield break; // Asegura que la coroutine devuelve un valor
    }

    void StartDialogue()
    {
        index = 0;
        StartCoroutine(TypeLine());
    }

    IEnumerator TypeLine()
    {
        foreach (char c in lines[index].ToCharArray())
        {
            textComponent.text += c;
            yield return new WaitForSeconds(textSpeed);
        }

        // Si hay más líneas, esperar hasta el siguiente tiempo especificado
        if (index < lines.Length - 1)
        {
            float waitTime = lineTimes[index + 1] - lineTimes[index] - (lines[index].Length * textSpeed);
            yield return new WaitForSeconds(waitTime > 0 ? waitTime : 0); // Asegúrate de no esperar un tiempo negativo
            NextLine();
        }
        else
        {
            gameObject.SetActive(false); // Desactiva el objeto una vez que todas las líneas se han mostrado
        }
    }

    void NextLine()
    {
        if (index < lines.Length - 1)
        {
            index++;
            textComponent.text = string.Empty;
            StartCoroutine(TypeLine());
        }
    }
}
